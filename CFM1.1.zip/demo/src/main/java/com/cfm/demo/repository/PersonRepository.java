package com.cfm.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cfm.demo.model.PersonEntity;

@Repository
public interface PersonRepository 
			extends CrudRepository<PersonEntity, Long> {

	List<PersonEntity> findByfirstName(String firstname);

}
