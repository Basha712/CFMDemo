INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email, city, zipcode, state) 
VALUES
  	('Gouse', 'Basha', 'howtodoinjava@gmail.com' , 'Atlanta' , '30301', 'Georgia'),
  	('John', 'Doe', 'xyz@email.com' , 'Edison' , '08817', 'NewJersey'),
  	('George', 'Doe', 'xyz@email.com' , 'polakamapadu' , '522512', 'Tamilnadu');