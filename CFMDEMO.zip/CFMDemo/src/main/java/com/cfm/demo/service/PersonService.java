package com.cfm.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cfm.demo.exception.RecordNotFoundException;
import com.cfm.demo.model.PersonEntity;
import com.cfm.demo.repository.PersonRepository;

@Service
public class PersonService {
	
	@Autowired
	PersonRepository repository;
	
	public List<PersonEntity> getAllEmployees()
	{
		List<PersonEntity> result = (List<PersonEntity>) repository.findAll();
		
		if(result.size() > 0) {
			return result;
		} else {
			return new ArrayList<PersonEntity>();
		}
	}
	
	public PersonEntity getEmployeeById(Long id) throws RecordNotFoundException 
	{
		Optional<PersonEntity> employee = repository.findById(id);
		
		if(employee.isPresent()) {
			return employee.get();
		} else {
			throw new RecordNotFoundException("No employee record exist for given id");
		}
	}
	
	public PersonEntity createOrUpdateEmployee(PersonEntity entity) 
	{
		if(entity.getId()  == null) 
		{
			entity = repository.save(entity);
			
			return entity;
		} 
		else 
		{
			Optional<PersonEntity> employee = repository.findById(entity.getId());
			
			if(employee.isPresent()) 
			{
				PersonEntity newEntity = employee.get();
				newEntity.setEmail(entity.getEmail());
				newEntity.setFirstName(entity.getFirstName());
				newEntity.setLastName(entity.getLastName());
				newEntity.setCity(entity.getCity());
				newEntity.setZipcode(entity.getZipcode());
				newEntity.setState(entity.getState());

				newEntity = repository.save(newEntity);
				
				return newEntity;
			} else {
				entity = repository.save(entity);
				
				return entity;
			}
		}
	} 
	
	public void deleteEmployeeById(Long id) throws RecordNotFoundException 
	{
		Optional<PersonEntity> employee = repository.findById(id);
		
		if(employee.isPresent()) 
		{
			repository.deleteById(id);
		} else {
			throw new RecordNotFoundException("No employee record exist for given id");
		}
	} 
}