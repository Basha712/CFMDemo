INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email, city, zipcode, state) 
VALUES
  	('Lokesh', 'Gupta', 'howtodoinjava@gmail.com' , 'undavalli' , '522501', 'Andhra'),
  	('John', 'Doe', 'xyz@email.com' , 'polakam' , '522511', 'Telangana'),
  	('Ramesh', 'Doe', 'xyz@email.com' , 'polakamapadu' , '522512', 'Tamilnadu');